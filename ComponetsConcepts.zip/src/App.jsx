import React, { useState } from "react";
import YtCard from "./components/YtCard";

function App() {
  let [inputValue, setInputValue] = useState("");
  // console.log(inputValue);

  // const [video, setVideos] = useState([
  //   {
  //     thumbnail: "",
  //     title: "",
  //     chName: "",
  //     views: "",
  //     chLogo: "",
  //     pubTime: "",
  //   },
  // ]);

  return (
    <>
      <header className="h-16 flex justify-between gap-2 items-center bg-neutral-800 text-neutral-50 px-5">
        <h2>MyTUBE</h2>
        <div className="flex gap-2 items-center">
          <input
            placeholder="Search Video Here.."
            className="border border-neutral-100 rounded px-2 py-1.5"
            onChange={(e) => {
              console.log(e.target.value);
              setInputValue(e.target.value);
            }}
          />
          <button>Search</button>
        </div>
      </header>
      <h1>{inputValue}</h1>
      <main>
        <section className="grid grid-cols-3 gap-4 p-5">
          <YtCard fName="Anam" lName="Yadav" />
          <YtCard fName="Deepak" lName="Yadav" />
          <YtCard fName="Harsh" lName="Maurya" />
          <YtCard fName="Ashish" lName="Yadav" />
        </section>
      </main>
    </>
  );
}

export default App;
